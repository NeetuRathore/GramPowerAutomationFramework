package TestRunner;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(
features = "src/test/resources/Feature",
glue={"stepDefination","hooks"},
tags= "@grampowerDashBoard",
publish = true,
plugin = {"pretty", "html:target/cucumber-reports.html", "json:target/cucumber-reports/CucumberTestReport.json"}
)

public class Runner extends AbstractTestNGCucumberTests{
	
	@BeforeClass(alwaysRun = true)
    public void setUpClass() {
        // Any setup needed before all tests
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() {
        // Any teardown needed after all tests
    }
		

}
