package stepDefination;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.BaseTest;
import PageObject.LoginPage;
import io.cucumber.java.en.*;

public class LoginStepDef{
	
	private final LoginPage loginPage;
	private WebDriver driver;

    public LoginStepDef() {
    	this.driver = BaseTest.getDriver();
        this.loginPage = new LoginPage(driver);

    }
    
    @Given("^User is on login page$")
    public void user_is_on_login_page() {
    	loginPage.verifyLoginPage();
    }
    
    @When("^User enter credentials (.*) and (.*)$")
    public void user_enter_valid_credentials(String userName, String password) throws Exception {
    	loginPage.enterValidCredentials(userName,password);
    }
    
    @And("^User click on the login button$")
    public void click_on_login_btn() {
    	loginPage.clickOnLoginBtn();
    }
    
    @Then("^User should be logged in to Gram Power$")
    public void verify_user_logged_in() {
    	String userName = "Automationuser";
    	loginPage.verifyLoggedIn(userName);
    }
    
    
    @Then("^User user will get invalid login error$")
    public void verify_user_get_invalid_error() {
    	loginPage.verifyInvalidLogin();
    }
    

}
