package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {
	
	protected static WebDriver driver;
	
	    public void openBrowser(){
	    	if (driver == null) {
	        driver = new ChromeDriver();
	        driver.get("https://data.grampower.com/hes/"); 
	        driver.manage().window().maximize();
	    	}
	    }
	    
	    public void closeBrowser(){
	    	if (driver != null) {
	            driver.quit();
	            driver = null;
	        }
	    }
	 
	 public static WebDriver getDriver() {
	        return driver;
	    }

}
