package PageObject;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class LoginPage {
	
	private final WebDriver driver;
	private By username = By.xpath("//input[@name='username']");
	private By password = By.xpath("//input[@name='password']");
	private By logInBtn = By.xpath("//input[@value='LOG IN']");
	private By logInPage = By.xpath("//h2[@class='agileits']");
	private By HomePage = By.xpath("//label[@class='btn user']");
	private By inValidError = By.xpath("//*[@id='register']/form/text()[7]");
	private By popUp = By.id("normal-slidedown");
	private By cancelBtn = By.id("onesignal-slidedown-cancel-button");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }
	
	public void verifyLoginPage() {
		Assert.assertEquals(driver.findElement(logInPage).getText(), "Log In");
	}
	
	public void enterValidCredentials(String userName, String Password) throws Exception {
		System.out.println(userName);
		System.out.println(Password);
		driver.findElement(username).sendKeys(userName);
		
		Thread.sleep(1000);
		
		driver.findElement(password).sendKeys(Password);
	}
	
	public void clickOnLoginBtn() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofMinutes(1));
		wait.until(ExpectedConditions.visibilityOfElementLocated(logInBtn));
		
		WebElement ele= driver.findElement(logInBtn);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", ele);
		
	}
	
	public void verifyLoggedIn(String userName) {
		try{
			Alert alert = driver.switchTo().alert(); 
			System.out.println(alert.getText());
			if(alert != null) {
				alert.dismiss();
			}
			System.out.println(alert.getText());
		}catch (Exception ex){
			   System.out.println("Alert is not present");
		}
		Assert.assertEquals(driver.findElement(HomePage).getText(),userName);
	}
	
	public void verifyInvalidLogin() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
        String script = "return document.evaluate(\"//*[@id='register']/form/text()[7]\", document, null, XPathResult.STRING_TYPE, null).stringValue;";
        String textContent = (String) js.executeScript(script);
        String op = "";
        
        for (int i = 0; i < textContent.length(); i++) {
            char ch = textContent.charAt(i);
 
            // Checking whether is white space or not
            if (!Character.isWhitespace(ch)) {
                op += ch;
            }
        }
        Assert.assertEquals(op, "invalidlogin");
		
	}

}
