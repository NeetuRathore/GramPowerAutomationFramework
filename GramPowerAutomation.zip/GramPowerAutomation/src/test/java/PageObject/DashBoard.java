package PageObject;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class DashBoard {
	
	private final WebDriver driver;
	private By sites = By.id("div_site_count");
	private By liveSites = By.id("div_live_site_count");
	private By configuredSites = By.id("h3_site_initilized");
	private By siteNeedsAction = By.id("h3_site_need_action");
	private By tariffRequest = By.id("div_tariff_count");
	private By rechargeInProcess = By.id("div_fail_recharge");
	private By rechargeDelay = By.id("div_delay_recharge");
	private By roomAssigned = By.id("div_assign_count");
	private By recentlyAssined = By.xpath("//h3[text()='Recently Assigned']");
	private By recentlyDeAssined = By.xpath("//h3[text()='Recently Deassigned']");
	private By retailDashBoardIframe = By.cssSelector("#retail_dashboard > iframe");
	private By listOfRecentlyAssignedSite = By.cssSelector("#ul_assigned_list>li");
	private By btnNavigateToMap = By.xpath("//div[@title='Click to navigate to MAP View']");
	private By navigateToMap = By.id("map-canvas");
	private By searchBar = By.xpath("//input[@id='search_tb']");
	private By searchBtn = By.xpath("//a[@id='search_bt']");
	private By consumerName = By.xpath("div.modal-body > div > div > table > tbody > tr:nth-child(1) > td:nth-child(3)");
	private By userNameBtn = By.xpath("//label[@class='btn user']");
	private By logOutBtn = By.className("external");
	
	
	public DashBoard(WebDriver driver) {
        this.driver = driver;
    }
	
	public void verifyElementsOfDashBoard() {
		Assert.assertEquals(driver.findElement(sites).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(liveSites).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(configuredSites).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(siteNeedsAction).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(tariffRequest).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(rechargeInProcess).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(rechargeDelay).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(roomAssigned).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(recentlyAssined).isDisplayed(),true);
		Assert.assertEquals(driver.findElement(recentlyDeAssined).isDisplayed(),true);
	}
	
	public void verifyNumberOfSiteandLiveSite() {
		String siteNum = driver.findElement(sites).getText();
		String liveSiteNum = driver.findElement(liveSites).getText();
		System.out.println("Number of sites: "+ siteNum.split(":")[1]);
		System.out.println("Number of live sites: "+ liveSiteNum.split(":")[1]);
		Assert.assertEquals(siteNum.matches(".*\\d.*"),true); //checking if string is containing any number
		Assert.assertEquals(liveSiteNum.matches(".*\\d.*"),true);
		
	}
	
	public boolean verifyCountOfRoomAssigned() {
		String countRoomAssigned = driver.findElement(roomAssigned).getText();
		System.out.println("Count of room assigned: "+ countRoomAssigned);
		return countRoomAssigned.matches(".*\\d.*");
	}
	
	public boolean verifyListofRecentlyAssigned() {
		ArrayList<WebElement> listRecentlyAssigned = (ArrayList<WebElement>) driver.findElements(listOfRecentlyAssignedSite);
		for(int i=0;i<listRecentlyAssigned.size();i++) {
			if(listRecentlyAssigned.get(i).isDisplayed()) {
				return true;
			}
		}
		return false;
	}
	
	public void clickToNavigateToMapView() {
		driver.findElement(btnNavigateToMap).click();	
		driver.switchTo().defaultContent();
	}
	
	public boolean verifyMapView() {
		return driver.findElement(navigateToMap).isDisplayed();	
	}
	
	public void enterConsumerName(String SiteName) {
		driver.switchTo().frame(driver.findElement(By.id("id_prepaid_iframe")));
		driver.findElement(searchBar).sendKeys(SiteName);	
	}
	
	public void clickOnSearchBtn() {
		driver.findElement(searchBtn).click();
	}
	
	public String verifyConsumerName() {
		return driver.findElement(consumerName).getText();
	}
	
	public void clickOnUserNameButton() {
		driver.switchTo().defaultContent();
		driver.findElement(userNameBtn).click();
	}
	
	public void selctLogoutOption() {
		driver.findElement(logOutBtn).click();
	}

}
