package stepDefination;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import Base.BaseTest;
import io.cucumber.java.*;

public class Hooks extends BaseTest{
	
	public Hooks() {
		openBrowser();
	}
	
	@Before
    public void setUp() {
        //openBrowser();
    }

    @After
    public void tearDown() {
        closeBrowser();
    }


}
