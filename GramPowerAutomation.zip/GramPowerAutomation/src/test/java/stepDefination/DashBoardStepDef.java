package stepDefination;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Base.BaseTest;
import PageObject.DashBoard;
import PageObject.LoginPage;
import io.cucumber.java.en.*;

public class DashBoardStepDef {
	
	private final LoginPage loginPage;
	private final DashBoard dashBoard;
	private WebDriver driver;
	private By retailDashBoardIframe = By.cssSelector("#retail_dashboard > iframe");
	
	public DashBoardStepDef() {
    	this.driver = BaseTest.getDriver();
        this.loginPage = new LoginPage(driver);
        this.dashBoard = new DashBoard(driver);
    }
	
	@Given("^User is logged into the Gram Power DashBoard$")
	public void user_is_logged_into_gram_power_dashboard() throws Exception {
		loginPage.enterValidCredentials("automationuser", "grampower");
		loginPage.clickOnLoginBtn();
	}
	
	@When("^User is on dashboard page$")
	public void user_is_on_dashbaord_page() {
		loginPage.verifyLoggedIn("Automationuser");
		driver.switchTo().frame(driver.findElement(retailDashBoardIframe));
	}
	
	@Then("^User is able to see all the required elements$")
	public void verify_all_elements_of_dashboard() {
		dashBoard.verifyElementsOfDashBoard();
	}
	
	@Then("^Verify that user can see number of site and live sites available$")
	public void verify_num_of_site_and_liveSite() {
		dashBoard.verifyNumberOfSiteandLiveSite();
	}
	
	@Then("^Verify that user can see count of room assigned$")
	public void verify_room_assigned_count() {
		Assert.assertEquals(dashBoard.verifyCountOfRoomAssigned(),true);
	}

	@Then("^Verify that user can see list of recently assigned sites$")
	public void verify_list_recent_assigned_sites() {
		Assert.assertEquals(dashBoard.verifyListofRecentlyAssigned(),true);
	}
	
	@And("^User click to navigate to map view$")
	public void click_on_sites() {
		dashBoard.clickToNavigateToMapView();
	}
	
	@Then("^Verify user navigate to Map View$")
	public void verify_map_view() {
		Assert.assertEquals(dashBoard.verifyMapView(),true);
	}
	
	@And("^User enter site name into search bar$")
	public void user_enter_consumer_name_into_searchbar() {
		dashBoard.enterConsumerName("GROUP METER TESTING");
	}
	
	@And("^User click on search button$")
	public void click_on_search_btn() {
		dashBoard.clickOnSearchBtn();
	}
	
    @Then("^Verify user is able to see consumer for site name$")
    public void verify_consume_name() {
    	Assert.assertEquals(dashBoard.verifyConsumerName(),"GROUP METER TESTING0203");
    }
    
    @And("^User click on username button$")
    public void user_click_on_user_btn() {
    	dashBoard.clickOnUserNameButton();
    }
    
    @When("^User select logout option from drop down$")
    public void user_select_logout_option() {
    	dashBoard.selctLogoutOption();
    }
}
